import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class PreviousRidesPage extends StatelessWidget {
  const PreviousRidesPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Previous Rides'),
        backgroundColor: Colors.black,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('rides')
            .where('userId', isEqualTo: user?.email)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final rides = snapshot.data?.docs ?? [];

          return ListView.builder(
            itemCount: rides.length,
            itemBuilder: (context, index) {
              final ride = rides[index].data() as Map<String, dynamic>;
              return Card(
                color: Colors.grey[900],
                margin: const EdgeInsets.all(8),
                child: ListTile(
                  title: Text(
                    'From: ${ride['pickup']}',
                    style: const TextStyle(color: Colors.white),
                  ),
                  subtitle: Text(
                    'To: ${ride['destination']}',
                    style: TextStyle(color: Colors.grey[400]),
                  ),
                  trailing: Text(
                    '₹${ride['fare']}',
                    style: const TextStyle(color: Colors.white, fontSize: 16),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}