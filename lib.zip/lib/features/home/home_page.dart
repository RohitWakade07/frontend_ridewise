import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../find_ride/FindRidePage.dart';
import '../previous_rides/previous_rides_page.dart';
import '../send_parcel/send_parcel_page.dart';
import 'ViewProfilePage.dart';


class HomePage extends StatefulWidget {
  final String email;
  final String phone;

  const HomePage({
    super.key,
    required this.email,
    required this.phone,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  late final TextEditingController _destinationController;
  late final AnimationController _wheelAnimationController;

  @override
  void initState() {
    super.initState();
    _destinationController = TextEditingController();
    _wheelAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat();
  }

  @override
  void dispose() {
    _destinationController.dispose();
    _wheelAnimationController.dispose();
    super.dispose();
  }

  void _navigateToFindRide() {
    if (_destinationController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter a destination'),
          backgroundColor: AppColors.errorRed,
        ),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => FindRidePage(
          destination: _destinationController.text.trim(),
        ),
      ),
    );
  }

  void _navigateToProfile() => Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => ProfilePage(
        email: widget.email,
        phone: widget.phone,
      ),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primaryBlack,
      appBar: AppBar(
        title: const Text('RideWise'),
        backgroundColor: AppColors.secondaryDark,
      ),
      drawer: _buildNavigationDrawer(),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildAnimatedHeader(),
            const SizedBox(height: 40),
            _buildDestinationInput(),
            const SizedBox(height: 32),
            _buildActionButton(
              text: 'Find Ride',
              icon: Icons.directions_car,
              onPressed: _navigateToFindRide,
            ),
            const SizedBox(height: 20),
            _buildActionButton(
              text: 'View Profile',
              icon: Icons.person,
              onPressed: _navigateToProfile,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNavigationDrawer() {
    return Drawer(
      backgroundColor: AppColors.secondaryDark,
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: const BoxDecoration(
              color: AppColors.primaryBlack,
            ),
            child: Center(
              child: Text(
                'RideWise Menu',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: AppColors.primaryWhite,
                ),
              ),
            ),
          ),
          _buildDrawerItem(
            icon: Icons.history,
            text: 'Ride History',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const PreviousRidesPage(),
              ),
            ),
          ),
          _buildDrawerItem(
            icon: Icons.local_shipping,
            text: 'Send Parcel',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const SendParcelPage(),
              ),
            ),
          ),
          _buildDrawerItem(
            icon: Icons.settings,
            text: 'Settings',
            onTap: () {}, // Add settings navigation
          ),
        ],
      ),
    );
  }

  Widget _buildAnimatedHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        RotationTransition(
          turns: _wheelAnimationController,
          child: const Icon(
            Icons.directions_bike,
            color: AppColors.accentGreen,
            size: 48,
          ),
        ),
        const SizedBox(width: 16),
        Text(
          'RideWise',
          style: Theme.of(context).textTheme.displaySmall?.copyWith(
            color: AppColors.primaryWhite,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildDestinationInput() {
    return TextField(
      controller: _destinationController,
      style: const TextStyle(color: AppColors.primaryWhite),
      decoration: InputDecoration(
        filled: true,
        fillColor: AppColors.secondaryDark,
        hintText: 'Enter your destination...',
        hintStyle: const TextStyle(color: AppColors.hintGrey),
        prefixIcon: const Icon(Icons.search, color: AppColors.accentGreen),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30),
          borderSide: BorderSide.none,
        ),
        contentPadding: const EdgeInsets.symmetric(
          vertical: 16,
          horizontal: 24,
        ),
      ),
    );
  }

  Widget _buildActionButton({
    required String text,
    required IconData icon,
    required VoidCallback onPressed,
  }) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        icon: Icon(icon, color: AppColors.primaryBlack),
        label: Text(
          text,
          style: const TextStyle(
            color: AppColors.primaryBlack,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.accentGreen,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
          ),
        ),
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String text,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: Icon(icon, color: AppColors.primaryWhite),
      title: Text(
        text,
        style: const TextStyle(color: AppColors.primaryWhite),
      ),
      onTap: onTap,
    );
  }
}